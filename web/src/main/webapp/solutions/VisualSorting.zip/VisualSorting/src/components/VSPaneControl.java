package components;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

public class VSPaneControl extends GridPane {
	
	// constructor
	public VSPaneControl() {
		initialized();
	}
	
	private void initialized() {
		setPadding(new Insets(1));
		setVgap(6);
		setAlignment(Pos.CENTER);
	}
	
	public void setSizeFromParent(Pane parentPane) {
		setStyle(getStyle()
				+"-fx-min-width: "+(VSButton.buttonWidth + 5)+";"
				+"-fx-max-width: "+(VSButton.buttonWidth + 5)+";"
				+"-fx-min-height: "+(parentPane.getMaxHeight() - parentPane.getPadding().getTop() * 2)+";"
				+"-fx-max-height: "+(parentPane.getMaxHeight() - parentPane.getPadding().getTop() * 2)+";");
	}
}
