package elements;

import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.transform.Rotate;
import move.Rotation;

public class Cube extends Box {
	private PhongMaterial material;
	public Rotate rotateCubeX;
	public Rotate rotateCubeY;
	public Rotate rotateCubeZ;
	
	EventHandler<MouseEvent> enteredCube;
	EventHandler<MouseEvent> exitedCube;
	EventHandler<MouseEvent> clickOnCube;
	
	private double width = 40;
	private double height = 40;
	private double depth = 40;
	private double distance = 80;
	
	private int number; // number on cube
	private int position; // position of cube in set
	private double firstX = 100;
	private double locationY = 170;
	
	// constructor
	public Cube(int number) {
		material = new PhongMaterial();
		rotateCubeX = new Rotate();
		rotateCubeY = new Rotate();
		rotateCubeZ = new Rotate();
		
		this.number = number;
		
		initialized();
	}
	
	// set the properties of a cube
	private void initialized() {
		
		// EVENTS ON THE CUBE
		
		enteredCube = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				increaseCube();
			}
		};
		
		exitedCube = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				decreaseCube();
			}
		};
		
		clickOnCube = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				rotateCube();
			}
		};
		
		// DESCRIPTION OF THE CUBE
		
		setWidth(width);
		setHeight(height);
		setDepth(depth);
		
		setTranslateX(firstX + position * distance);
		setTranslateY(locationY);
		setTranslateZ(0);
		
		rotateCubeX.setAxis(Rotate.X_AXIS);
		rotateCubeX.setAngle(30);
		getTransforms().add(rotateCubeX);
		
		rotateCubeY.setAxis(Rotate.Y_AXIS);
		rotateCubeY.setAngle(0);
		getTransforms().add(rotateCubeY);
		
		rotateCubeZ.setAxis(Rotate.Z_AXIS);
		rotateCubeZ.setAngle(0);
		getTransforms().add(rotateCubeZ);
		
        material.setDiffuseColor(Color.TRANSPARENT);
        material.setSpecularColor(Color.TRANSPARENT);
        material.setSelfIlluminationMap(new Image("file:images/digits/" + number + ".png"));
        setMaterial(material);
        
		setFocusTraversable(false);
		
		setOnMouseEntered(enteredCube);
		setOnMouseExited(exitedCube);
		setOnMouseClicked(clickOnCube);
	}
	
	private void increaseCube() {
		setWidth(width * 1.5);
		setHeight(height * 1.5);
		setDepth(depth * 1.5);
	}
	
	private void decreaseCube() {
		setWidth(width);
		setHeight(height);
		setDepth(depth);
	}
	
	private void rotateCube() {
		new Rotation(this).start();
	}
	
	public void changeCubeIfVerticalResize(double coefficient) {
			locationY = locationY * coefficient;
			setTranslateY(locationY);
	}
	
	public void changeCubeIfHorizontalResize(double coefficient) {
		distance = distance * coefficient;
		firstX = firstX * coefficient;
		setTranslateX(firstX + position * distance);
		width = width * coefficient;
		height = height * coefficient;
		depth = depth * coefficient;
		setWidth(width);
		setHeight(height);
		setDepth(depth);
	}
	
	// getter
	public int getNumber() {
		return this.number;
	}

	public int getPosition() {
		return position;
	}
	
	public double getLocationY() {
		return locationY;
	}

	public void setPosition(int position) {
		this.position = position;
		setTranslateX(firstX + position * distance);
		setTranslateY(locationY);
		setTranslateZ(0);
	}
}
