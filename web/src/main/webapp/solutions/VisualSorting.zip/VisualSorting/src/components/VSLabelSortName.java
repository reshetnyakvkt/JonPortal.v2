package components;

import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class VSLabelSortName extends Label {

	public VSLabelSortName() {
		initialized();
	}
	
	private void initialized() {
		setText("Select method of sorting");
		setStyle("-fx-background-color: null;"
				+"-fx-text-fill: red;"
				+"-fx-font-size: 15;"
				+"-fx-font-weight: bold;");
	}
	
	public void setLocation(Pane parentPane) {
		setTranslateX(parentPane.getMinWidth() / 3);
		setTranslateY(10);
	}
}
