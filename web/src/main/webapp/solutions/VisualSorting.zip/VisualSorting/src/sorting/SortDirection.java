package sorting;

public enum SortDirection {
	ascending(1), 
	descending(-1);
	
	private int number;
	
	private SortDirection(int number) {
		this.number = number;
	}
	
	public int getDirection() {
		return number;
	}
}
