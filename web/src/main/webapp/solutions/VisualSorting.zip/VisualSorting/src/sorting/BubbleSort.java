package sorting;

import application.VSApplication;
import elements.Cube;
import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import move.MoveDown;
import move.MoveUp;
import move.Swap;

public class BubbleSort extends Thread {
	private Cube[] arrayCubes;
	private SortDirection sortDirection;
	private Pane pane;
	
	// constructor
	public BubbleSort(Cube[] arrayCubes, SortDirection sortDirection, Pane pane) {
		this.arrayCubes = arrayCubes;
		this.sortDirection = sortDirection;
		this.pane = pane;
	}
	
	@Override
	public void run() {
		try {
			for (int i=0; i < arrayCubes.length; i++) {
				for (int j=0; j < arrayCubes.length - i - 1; j++) {
					Thread.sleep(1000);
					while(VSApplication.pause) { // sleep, while the button "pause" is pressed
						Thread.sleep(100);
						if (VSApplication.stop) {
							printCompleteSort();
							return;
						}
					}
					if (VSApplication.stop) {
						printCompleteSort();
						return;
					}
					MoveUp moveUp = new MoveUp(getCube(j), getCube(j+1));
					moveUp.start();
					moveUp.join();
					Thread.sleep(1000);
					while(VSApplication.pause) {
						Thread.sleep(100);
						if (VSApplication.stop) {
							printCompleteSort();
							return;
						}
					}
					if (VSApplication.stop) {
						printCompleteSort();
						return;
					}
					MoveDown moveDown = new MoveDown(getCube(j), getCube(j+1));
					moveDown.start();
					moveDown.join();
					
					// unit of sorting
					if (sortDirection.getDirection() * (getCube(j+1).getNumber() - getCube(j).getNumber()) < 0) {
						Thread.sleep(1000);
						while(VSApplication.pause) {
							Thread.sleep(100);
							if (VSApplication.stop) {
								printCompleteSort();
								return;
							}
						}
						if (VSApplication.stop) {
							printCompleteSort();
							return;
						}
						Swap swap = new Swap(getCube(j), getCube(j+1)); // swap the cubes
						swap.start();
						swap.join();
					}
					
				}
			}
			VSApplication.start = false;
			printCompleteSort();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	// getter of cube
	private Cube getCube(int position) {
		for (int i = 0; i < arrayCubes.length; i++) {
			if (arrayCubes[i].getPosition() == position) {
				return arrayCubes[i];
			}
		}
		return null;
	}
	
	private void printCompleteSort() {
		Platform.runLater(()->{
			Label labelCompleted = new Label();
			if (!VSApplication.stop) {
				// if sorting completed
				labelCompleted.setText("Sorting Completed");
			}
			else {
				// if sorting stopped
				labelCompleted.setText("Sorting Stopped");
			}
			labelCompleted.setTranslateX(pane.getMinWidth() / 3);
			labelCompleted.setTranslateY(arrayCubes[0].getTranslateY() - 80);
			labelCompleted.setStyle("-fx-background-color: null;"
									+"-fx-text-fill: yellow;"
									+"-fx-font-size: 25;"
									+"-fx-font-weight: bold;");
			pane.getChildren().add(2, labelCompleted);
		});
	}
}
