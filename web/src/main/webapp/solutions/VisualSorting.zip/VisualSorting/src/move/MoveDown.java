package move;

import application.VSApplication;
import elements.Cube;
import javafx.application.Platform;

public class MoveDown extends Thread {
	private Cube cube1;
	private Cube cube2;

	public MoveDown(Cube cube1, Cube cube2) {
		this.cube1 = cube1;
		this.cube2 = cube2;
	}
	
	@Override
	public void run() {
		for (int i=0; i < cube1.getHeight(); i++) {
			
			Platform.runLater(()->{
				cube1.setTranslateY(cube1.getTranslateY() + 1);
				cube2.setTranslateY(cube2.getTranslateY() + 1);
			});
			
			try {
				Thread.sleep(10);
				while(VSApplication.pause) {
					Thread.sleep(100);
					if (VSApplication.stop) {
						return;
					}
				}
				if (VSApplication.stop) {
					return;
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
