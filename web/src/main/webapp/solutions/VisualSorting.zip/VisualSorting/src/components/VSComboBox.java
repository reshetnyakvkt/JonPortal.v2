package components;

import java.util.ArrayList;

import javafx.scene.control.ComboBox;
import javafx.scene.control.Tooltip;

public class VSComboBox extends ComboBox<String> {
	private ArrayList<String> sortsList; // list for ComboBox
	
	// constructor
	public VSComboBox() {
		sortsList = new ArrayList<>();
		fillSortList();
		initialized();
	}
	
	// fill list for ComboBox
	private void fillSortList() {
		sortsList.add("Selection Sort");
		sortsList.add("Bubble Sort");
		sortsList.add("Insertion Sort");
		sortsList.add("Shell Sort");
	}
	
	// description of the button
	private void initialized() {
		getItems().addAll(sortsList);
		setStyle("-fx-min-width: "+VSButton.buttonWidth+";"
				+"-fx-min-height: "+VSButton.buttonHeight+";"
				+"-fx-background-color: null;"
				+"-fx-background-image: url(\"file:images/select.png\");"
				+"-fx-background-size: 65% 80%;"
				+ "-fx-background-position: top;"
				+ "-fx-background-repeat: no-repeat;");
		setTooltip(setTooltipStyle("Select the Type of Sorting"));
		setEditable(false);
		setFocusTraversable(false);
	}
		
	// create tooltip on the button
	private Tooltip setTooltipStyle(String text) {
		Tooltip tooltip = new Tooltip(text);
		tooltip.setStyle("-fx-font-weight: bold;"
						+"-fx-font-size: 12;"
						+"-fx-text-fill: rgb(250,0,0);"
						+"-fx-background-color: yellow;");
		return tooltip;
	}
}
