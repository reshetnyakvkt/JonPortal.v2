package move;

import elements.Cube;
import javafx.application.Platform;

public class Rotation extends Thread {
	private Cube cube;
	
	public Rotation(Cube cube) {
		this.cube = cube;
	}
	
	@Override
	public void run() {
		cube.rotateCubeY.setAngle(2);
		
		for (int i=0; i < 180; i++) {
			
			Platform.runLater(()->{
				cube.getTransforms().add(cube.rotateCubeY);
			});
			
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
