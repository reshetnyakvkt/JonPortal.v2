package components;

import javafx.scene.layout.Pane;

public class VSPaneScreen extends Pane {

	public VSPaneScreen() {
		initialized();
	}
	
	private void initialized() {
		setStyle(getStyle()
				+"-fx-background-image: url(\"file:images/wall.jpg\");"
				+"-fx-background-size: 100% 100%;"
				+"-fx-background-position: center;"
				+"-fx-background-repeat: no-repeat;"
				+"-fx-background-color: rgb(0,120,0);"
				+"-fx-border-width: 1;"
				+"-fx-border-color: black white white black;");
	}
}
