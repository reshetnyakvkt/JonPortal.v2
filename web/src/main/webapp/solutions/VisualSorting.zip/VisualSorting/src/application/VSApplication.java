package application;

import java.util.ArrayList;
import java.util.Random;

import components.VSPaneRoot;
import components.VSButton;
import components.VSPaneScreen;
import components.VSComboBox;
import components.VSLabelPause;
import components.VSPaneControl;
import components.VSLabelSortName;
import elements.Cube;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import move.Disposition;
import sorting.BubbleSort;
import sorting.InsertionSort;
import sorting.SelectionSort;
import sorting.ShellSort;
import sorting.SortDirection;

public class VSApplication extends Application {
	private Scene scene;
	private PerspectiveCamera camera;
	private VSPaneRoot root;
	private VSPaneControl controlPane;
	private VSComboBox comboBoxSelectSort; // selection method of sort
	private VSButton buttonNewSet; // button "new set"
	private VSButton buttonAscendingSort; // button "sort in ascending"
	private VSButton buttonDescendingSort; // button "sort in descending"
	private VSButton buttonPause; // button "pause sorting"
	private VSButton buttonStop; // button "stop"
	private VSButton buttonClear; // button "clear screen"
	private VSPaneScreen screenPane;
	private VSLabelSortName labelSortName;
	private VSLabelPause labelPause;
	
	private Cube[] arrayCubes;
	
	EventHandler<ActionEvent> selectedMenuItem; // if selected item of menu
	EventHandler<ActionEvent> clickOnButtonNewSet; // press on the button "new set"
	EventHandler<ActionEvent> clickOnButtonAscendingSort; // press on the button "sort in ascending"
	EventHandler<ActionEvent> clickOnButtonDescendingSort; // press on the button "sort in descending"
	EventHandler<ActionEvent> clickOnButtonPause; // press on the button "pause sorting"
	EventHandler<ActionEvent> clickOnButtonStop; // press on the button "stop sorting"
	EventHandler<ActionEvent> clickOnButtonClear; // press on the button "clear screen"
	EventHandler<WindowEvent> createCubeSet; // create set of cubes
	EventHandler<WindowEvent> exitApplication; // exit application
	ChangeListener<Number> changeSceneWidth; // change width of window
	ChangeListener<Number> changeSceneHeight; // change height of window

	private boolean initilizedCubeArray = false; // ��������� ������������� �����
	private boolean ready; // ��������� ���������� � ������� ����������
	public static boolean start; // ��������� ������������� ����������
	public static boolean pause; // ��������� �����/����������
	public static boolean stop; // ��������� ��������� ����������
	
	// constructor
	public VSApplication() {
		camera = new PerspectiveCamera();
		root = new VSPaneRoot();
		controlPane = new VSPaneControl();
		comboBoxSelectSort = new VSComboBox();
		buttonNewSet = new VSButton();
		buttonAscendingSort = new VSButton();
		buttonDescendingSort = new VSButton();
		buttonPause = new VSButton();
		buttonStop = new VSButton();
		buttonClear = new VSButton();
		screenPane = new VSPaneScreen();
		labelSortName = new VSLabelSortName();
		labelPause = new VSLabelPause();
		
		arrayCubes = new Cube[10];
	}
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		stage.setMinHeight(400);
		stage.setMinWidth(950);
		
		root.setMinSize(stage.getMinWidth(), stage.getMinHeight());
		
		// EVENTS ON THE CONTROL PANE COMPONENTS
		
		selectedMenuItem = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				selectMenuItem();
			}
		};
		
		clickOnButtonNewSet = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				createNewSet();
			}
		};
		
		clickOnButtonAscendingSort = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				sort(SortDirection.ascending);
			}
		};
		
		clickOnButtonDescendingSort = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				sort(SortDirection.descending);
			}
		};
		
		clickOnButtonPause = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				pauseSorting();
			}
		};
		
		clickOnButtonStop = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				stopSorting();
			}
		};
		
		clickOnButtonClear = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				clearScreen();
			}
		};
		
		// DESCRIPTION OF THE CONTROL PANE COMPONENTS
		
		comboBoxSelectSort.setOnAction(selectedMenuItem);
		controlPane.add(comboBoxSelectSort, 0, 1);
		
		buttonNewSet.setProperties("set.png", "Create a New Set");
		buttonNewSet.setOnAction(clickOnButtonNewSet);
		controlPane.add(buttonNewSet, 0, 0);
		
		buttonAscendingSort.setProperties("sort_ascending.png", "Sort in Ascending");
		buttonAscendingSort.setOnAction(clickOnButtonAscendingSort);
		controlPane.add(buttonAscendingSort, 0, 2);
		
		buttonDescendingSort.setProperties("sort_descending.png", "Sort in Descending");
		buttonDescendingSort.setOnAction(clickOnButtonDescendingSort);
		controlPane.add(buttonDescendingSort, 0, 3);
		
		buttonPause.setProperties("pause.png", "Pause/Continue Sorting");
		buttonPause.setOnAction(clickOnButtonPause);
		controlPane.add(buttonPause, 0, 4);
		
		buttonStop.setProperties("stop.png", "Stop Sorting");
		buttonStop.setOnAction(clickOnButtonStop);
		controlPane.add(buttonStop, 0, 5);
		
		buttonClear.setProperties("clear.png", "Clear Screen");
		buttonClear.setOnAction(clickOnButtonClear);
		controlPane.add(buttonClear, 0, 6);
		
		controlPane.setSizeFromParent(root);
		root.add(controlPane, 0, 0);
		
		// DESCRIPTION OF THE CANVAS COMPONENTS
		
		screenPane.setMinWidth(root.getMinWidth() - controlPane.getMinWidth() - root.getPadding().getLeft() * 2 - root.getHgap());
		screenPane.setMaxWidth(root.getMaxWidth() - controlPane.getMaxWidth() - root.getPadding().getLeft() * 2 - root.getHgap());
		screenPane.setMinHeight(root.getMinHeight() - root.getPadding().getTop() * 2);
		screenPane.setMaxHeight(root.getMaxHeight() - root.getPadding().getTop() * 2);
		
		labelSortName.setLocation(screenPane);
		screenPane.getChildren().add(0, labelSortName);
		
		labelPause.setLocation(screenPane);
		screenPane.getChildren().add(0, labelPause);
		
		root.add(screenPane, 1, 0);
		
		// EVENTS OF THE APPLICATION WINDOW
		
		createCubeSet = new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				initilizeCubeArray();
			}
		};
		
		exitApplication = new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				stage.close();
				System.exit(0);
			}
		};
		
		changeSceneWidth = new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				changeWindowWidth(oldValue, newValue);
			}
		};
		
		changeSceneHeight = new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				changeWindowHeight(oldValue, newValue);
			}
		};
		
		// DESCRIPTION OF THE APPLICATION WINDOW
		
		scene = new Scene(root);
		camera.setFarClip(10000); // ������������� ������� ���������
		scene.setCamera(camera);
		scene.widthProperty().addListener(changeSceneWidth);
		scene.heightProperty().addListener(changeSceneHeight);
		stage.setScene(scene);
		
		stage.setTitle("Visual Sorting");
		stage.getIcons().add(new Image("file:images/sorting.png"));
		stage.centerOnScreen();
		stage.setResizable(true);
		stage.sizeToScene();
		stage.setOnShowing(createCubeSet);
		stage.setOnCloseRequest(exitApplication);
		stage.setFullScreen(true);
		stage.setFullScreenExitHint("");
		stage.setFullScreenExitKeyCombination(null);
		stage.show();
	}
	
	// HANDLE METHODS
	
	// change width of window end its components
	private void changeWindowWidth(Number oldValue, Number newValue) {
		screenPane.setMinWidth(scene.getWidth() - controlPane.getMinWidth() - root.getPadding().getLeft() * 2 - root.getHgap());
		screenPane.setMaxWidth(scene.getWidth() - controlPane.getMaxWidth() - root.getPadding().getLeft() * 2 - root.getHgap());
		labelSortName.setTranslateX(screenPane.getMinWidth() / 3);
		labelPause.setTranslateX(screenPane.getMinWidth() / 3 + 80);
		
		// change location and size of cubes
		if (initilizedCubeArray && ((double)oldValue != 0)) {
			for (Cube cube : arrayCubes) {
				cube.changeCubeIfHorizontalResize((double)newValue/(double)oldValue);
			}
		}
	}
	
	// change height of window end its components
	private void changeWindowHeight(Number oldValue, Number newValue) {
		screenPane.setMinHeight(scene.getHeight() - root.getPadding().getTop() * 2);
		screenPane.setMaxHeight(scene.getHeight() - root.getPadding().getTop() * 2);
		labelPause.setTranslateY(screenPane.getMinHeight() - 35);
		
		// change location of cubes
		if (initilizedCubeArray && ((double)oldValue != 0)) {
			for (Cube cube : arrayCubes) {
				cube.changeCubeIfVerticalResize((double)newValue/(double)oldValue);
			}
		}
	}
	
	// �������� ��� ������ ������ ����������� ����
	private void selectMenuItem() {
		labelSortName.setText(comboBoxSelectSort.getSelectionModel().getSelectedItem());
	}
	
	// create new set of cubes
	private void createNewSet() {
		if (!start) {
			clearScreen();
			ready = true;
			ArrayList<Integer> listRandom = new ArrayList<>();
			boolean bool = true;
			int random = 0;
			for (int i = 0; i < arrayCubes.length; i++) {
				bool = true;
				while (bool) {
					bool = false;
					random = new Random().nextInt(10);
					for (int element : listRandom) {
						if (element == random) {
							bool = true;
							break;
						}
					}
				}
				listRandom.add(random);
				arrayCubes[i].setPosition(random);
				arrayCubes[i].setVisible(false);
				screenPane.getChildren().add(1, arrayCubes[i]);
			}
			new Disposition(arrayCubes).start();
		}
	}
	
	// sort in ascending or in descending
	private void sort(SortDirection sortDirection) {
		if (!start && ready && comboBoxSelectSort.getSelectionModel().getSelectedItem() != null) {
			ready = false;
			stop = false;
			start = true;
			
			// write a name of the sort and a direction of the sort to label
			String sortName = new String();
			switch (sortDirection) {
			case ascending:
				sortName = comboBoxSelectSort.getSelectionModel().getSelectedItem() + " in Ascending";
				break;
			case descending:
				sortName = comboBoxSelectSort.getSelectionModel().getSelectedItem() + " in Descending";
				break;
			}
			
			// run sort
			switch (comboBoxSelectSort.getSelectionModel().getSelectedIndex()) {
			case 0:
				labelSortName.setText(sortName);
				new SelectionSort(arrayCubes, sortDirection, screenPane).start();
				break;
			case 1:
				labelSortName.setText(sortName);
				new BubbleSort(arrayCubes, sortDirection, screenPane).start();
				break;
			case 2:
				labelSortName.setText(sortName);
				new InsertionSort(arrayCubes, sortDirection, screenPane).start();
				break;
			case 3:
				labelSortName.setText(sortName);
				new ShellSort(arrayCubes, sortDirection, screenPane).start();
				break;
			}
		}
	}
	
	// pause sorting
	private void pauseSorting() {
		if (start) {
			pause = ! pause;
			if (pause) {
				labelPause.setText("Pause");
			}
			else {
				labelPause.setText("");
			}
		}
	}
	
	// stop to sort
	private void stopSorting() {
		if (start) {
			stop = true;
			start = false;
			pause = false;
			labelPause.setText("");
		}
	}
	
	// delete cubes from pane
	private void clearScreen() {
		if (!start) {
			ready = false;
			stop = false;
			screenPane.getChildren().clear();
			if (comboBoxSelectSort.getSelectionModel().getSelectedItem() != null) {
				labelSortName.setText(comboBoxSelectSort.getSelectionModel().getSelectedItem());
			}
			else{
				labelSortName.setText("Select method of sorting");
			}
			screenPane.getChildren().add(0, labelSortName);
			screenPane.getChildren().add(0, labelPause);
			labelPause.setText("");
		}
	}
	
	// initialization of array of cubes
	private void initilizeCubeArray() {
		for (int i = 0; i < arrayCubes.length; i++) {
			arrayCubes[i] = new Cube(i);
		}
		initilizedCubeArray = true;
	}
}