package components;

import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class VSLabelPause extends Label {

	public VSLabelPause() {
		initialized();
	}
	
	private void initialized() {
		setText("");
		setStyle("-fx-background-color: null;"
								+"-fx-text-fill: red;"
								+"-fx-font-size: 18;"
								+"-fx-font-weight: bold;");
	}
	
	public void setLocation(Pane parentPane) {
		setTranslateX(parentPane.getMinWidth() / 5);
		setTranslateY(parentPane.getMinHeight() - 35);
	}
}
