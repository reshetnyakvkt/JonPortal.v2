package move;

import elements.Cube;
import javafx.application.Platform;

public class Disposition extends Thread {
	private Cube[] arrayCubes;
	private final int distance = 720;
	private final int stepOfDiscret = 1;
	
	public Disposition(Cube[] arrayCubes) {
		this.arrayCubes = arrayCubes;
	}
	
	@Override
	public void run() {
		
		Platform.runLater(()->{
			for (int i=0; i < arrayCubes.length; i++) {
				arrayCubes[i].setTranslateZ(distance);
				arrayCubes[i].setVisible(true);
			}
		});

		for (int count = distance; count > 0; count--) {

			Platform.runLater(()->{
				for (int i=0; i < arrayCubes.length; i++) {
					arrayCubes[i].setTranslateZ(arrayCubes[i].getTranslateZ() - stepOfDiscret);
					arrayCubes[i].rotateCubeX.setAngle(arrayCubes[i].rotateCubeX.getAngle() + 1);
				}
			});
			
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
