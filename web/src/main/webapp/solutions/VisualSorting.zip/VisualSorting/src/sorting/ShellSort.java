package sorting;

import application.VSApplication;
import elements.Cube;
import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import move.MoveDown;
import move.MoveUp;
import move.Swap;

public class ShellSort extends Thread {
	private Cube[] arrayCubes;
	private SortDirection sortDirection;
	private Pane pane;

	// constructor
	public ShellSort(Cube[] arrayCubes, SortDirection sortDirection, Pane pane) {
		this.arrayCubes = arrayCubes;
		this.sortDirection = sortDirection;
		this.pane = pane;
	}

	@Override
	public void run() {
		try {
			int step = arrayCubes.length;
			while ((step /= 2) > 0) {
				for (int i = 0; (i + step) < arrayCubes.length; i++) {
					Thread.sleep(1000);
					while (VSApplication.pause) { // sleep, while the button "pause" is pressed
						Thread.sleep(100);
						if (VSApplication.stop) {
							printCompleteSort();
							return;
						}
					}
					if (VSApplication.stop) {
						printCompleteSort();
						return;
					}
					MoveUp moveUp = new MoveUp(getCube(i), getCube(i+step));
					moveUp.start();
					moveUp.join();
					Thread.sleep(1000);
					while (VSApplication.pause) {
						Thread.sleep(100);
						if (VSApplication.stop) {
							printCompleteSort();
							return;
						}
					}
					if (VSApplication.stop) {
						printCompleteSort();
						return;
					}
					MoveDown moveDown = new MoveDown(getCube(i), getCube(i+step));
					moveDown.start();
					moveDown.join();
					
					if (sortDirection.getDirection() * (getCube(i+step).getNumber() - getCube(i).getNumber()) < 0) {
						Thread.sleep(1000);
						while (VSApplication.pause) {
							Thread.sleep(100);
							if (VSApplication.stop) {
								printCompleteSort();
								return;
							}
						}
						if (VSApplication.stop) {
							printCompleteSort();
							return;
						}
						Swap swap = new Swap(getCube(i), getCube(i+step)); // swap the cubes
						swap.start();
						swap.join();
						
						for (int j = i; j - step >= 0; j -= step) {
							Thread.sleep(1000);
							while (VSApplication.pause) { // sleep, while the button "pause" is pressed
								Thread.sleep(100);
								if (VSApplication.stop) {
									printCompleteSort();
									return;
								}
							}
							if (VSApplication.stop) {
								printCompleteSort();
								return;
							}
							MoveUp moveUp2 = new MoveUp(getCube(j-step), getCube(j));
							moveUp2.start();
							moveUp2.join();
							Thread.sleep(1000);
							while (VSApplication.pause) {
								Thread.sleep(100);
								if (VSApplication.stop) {
									printCompleteSort();
									return;
								}
							}
							if (VSApplication.stop) {
								printCompleteSort();
								return;
							}
							MoveDown moveDown2 = new MoveDown(getCube(j-step), getCube(j));
							moveDown2.start();
							moveDown2.join();

							// unit of sorting
							if (sortDirection.getDirection() * (getCube(j).getNumber() - getCube(j-step).getNumber()) < 0) {
								Thread.sleep(1000);
								while (VSApplication.pause) {
									Thread.sleep(100);
									if (VSApplication.stop) {
										printCompleteSort();
										return;
									}
								}
								if (VSApplication.stop) {
									printCompleteSort();
									return;
								}
								Swap swap2 = new Swap(getCube(j-step), getCube(j)); // swap the cubes
								swap2.start();
								swap2.join();
							}
							else {
								break;
							}
						}
					}
				}
			}
			VSApplication.start = false;
			printCompleteSort();			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// getter of cube
	private Cube getCube(int position) {
		for (int i = 0; i < arrayCubes.length; i++) {
			if (arrayCubes[i].getPosition() == position) {
				return arrayCubes[i];
			}
		}
		return null;
	}
	
	private void printCompleteSort() {
		Platform.runLater(()->{
			Label labelCompleted = new Label();
			if (!VSApplication.stop) {
				// if sorting completed
				labelCompleted.setText("Sorting Completed");
			}
			else {
				// if sorting stopped
				labelCompleted.setText("Sorting Stopped");
			}
			labelCompleted.setTranslateX(pane.getMinWidth() / 3);
			labelCompleted.setTranslateY(arrayCubes[0].getTranslateY() - 80);
			labelCompleted.setStyle("-fx-background-color: null;"
									+"-fx-text-fill: yellow;"
									+"-fx-font-size: 25;"
									+"-fx-font-weight: bold;");
			pane.getChildren().add(2, labelCompleted);
		});
	}
}