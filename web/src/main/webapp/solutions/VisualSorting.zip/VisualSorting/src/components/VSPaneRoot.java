package components;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;

public class VSPaneRoot extends GridPane {
	
	public VSPaneRoot() {
		initialized();
	}
	
	private void initialized() {
		setPadding(new Insets(5));
		setAlignment(Pos.CENTER);
		setHgap(5);
		setStyle("-fx-background-color: rgb(150, 50, 10);");
	}
}
