package components;

import javafx.scene.layout.Pane;

public class PaneScreen extends Pane {
	
	public PaneScreen() {
		initialized();
	}
	
	private void initialized() {
		setStyle(getStyle()
				+"-fx-background-position: center;"
				+"-fx-background-color: blue;");
	}
}
