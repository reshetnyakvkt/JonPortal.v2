package components;

import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.Sphere;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;

public class Space extends Pane {
	public static Light.Point light;

	public Space() {
		initialized();
	}

	private void initialized() {
		setStyle(getStyle() 
				+ "-fx-min-width: 600;" 
				+ "-fx-max-width: 600;" 
				+ "-fx-min-height: 600;"
				+ "-fx-max-height: 600;" 
				+ "-fx-background-image: url(\"file:images/space.jpg\");"
				+ "-fx-background-position: center;" 
				+ "-fx-background-size: 100% 100%;"
				+ "-fx-background-repeat: no-repeat;" 
				+ "-fx-background-color: darkblue;");

		//
		Sphere leftBall = new Sphere(80);
		leftBall.setTranslateX(900);
		leftBall.setTranslateY(100);
		PhongMaterial materialLB = new PhongMaterial(Color.LAWNGREEN);
		leftBall.setMaterial(materialLB);
		getChildren().add(leftBall);
		
		//
		Cylinder leftCylinder = new Cylinder(12, 250);
		leftCylinder.setTranslateX(1000);
		leftCylinder.setTranslateY(200);
		leftCylinder.setTranslateZ(100);
		PhongMaterial materialLC = new PhongMaterial(Color.BROWN);
		leftCylinder.setMaterial(materialLC);
		getChildren().add(leftCylinder);

		Rotate rotateLCX = new Rotate(-60);
		rotateLCX.setAxis(Rotate.X_AXIS);
		leftCylinder.getTransforms().add(rotateLCX);

		Rotate rotateLCZ = new Rotate(-27);
		rotateLCZ.setAxis(Rotate.Z_AXIS);
		leftCylinder.getTransforms().add(rotateLCZ);
		
		//
		Sphere rightBall = new Sphere(80);
		rightBall.setTranslateX(1300);
		rightBall.setTranslateY(100);
		PhongMaterial materialRB = new PhongMaterial(Color.LAWNGREEN);
		rightBall.setMaterial(materialRB);
		getChildren().add(rightBall);
		
		//
		Cylinder rightCylinder = new Cylinder(12, 250);
		rightCylinder.setTranslateX(1200);
		rightCylinder.setTranslateY(200);
		rightCylinder.setTranslateZ(100);
		PhongMaterial materialRC = new PhongMaterial(Color.BROWN);
		rightCylinder.setMaterial(materialRC);
		getChildren().add(rightCylinder);

		Rotate rotateRCX = new Rotate(-60);
		rotateRCX.setAxis(Rotate.X_AXIS);
		rightCylinder.getTransforms().add(rotateRCX);

		Rotate rotateRCZ = new Rotate(27);
		rotateRCZ.setAxis(Rotate.Z_AXIS);
		rightCylinder.getTransforms().add(rotateRCZ);
		
		//
		Sphere childBall = new Sphere(150);
		childBall.setTranslateX(1100);
		childBall.setTranslateY(300);
		PhongMaterial materialCB = new PhongMaterial(Color.LAWNGREEN);
		childBall.setMaterial(materialCB);
		getChildren().add(childBall);

		//
		Cylinder childCylinder = new Cylinder(21, 650);
		childCylinder.setTranslateX(860);
		childCylinder.setTranslateY(520);
		childCylinder.setTranslateZ(100);
		PhongMaterial materialCC = new PhongMaterial(Color.BROWN);
		childCylinder.setMaterial(materialCC);
		getChildren().add(childCylinder);

		Rotate rotateCCX = new Rotate(-60);
		rotateCCX.setAxis(Rotate.X_AXIS);
		childCylinder.getTransforms().add(rotateCCX);

		Rotate rotateCCZ = new Rotate(28);
		rotateCCZ.setAxis(Rotate.Z_AXIS);
		childCylinder.getTransforms().add(rotateCCZ);

		//
		Sphere parentBall = new Sphere(800);
		parentBall.setTranslateX(200);
		parentBall.setTranslateY(1200);
		PhongMaterial materialPB = new PhongMaterial(Color.LAWNGREEN);
		parentBall.setMaterial(materialPB);
		getChildren().add(parentBall);

		//
		Text text0 = new Text("Binary Search Tree");
		text0.setTranslateX(101);
		text0.setTranslateY(201);
		text0.setStrokeWidth(20);
		text0.setStyle(text0.getStyle()
				+"-fx-fill: black;"
				+"-fx-font-size: 50;"
				+"-fx-font-weight: bold;"
				+"-fx-font-family: Garamond;");
		getChildren().add(text0);
		
		//
		Text text1 = new Text("Binary Search Tree");
		text1.setTranslateX(99);
		text1.setTranslateY(199);
		text1.setStrokeWidth(20);
		text1.setStyle(text1.getStyle()
				+"-fx-fill: lightblue;"
				+"-fx-font-size: 50;"
				+"-fx-font-weight: bold;"
				+"-fx-font-family: Garamond;");
		getChildren().add(text1);
		
		//
		Text text = new Text("Binary Search Tree");
		text.setTranslateX(100);
		text.setTranslateY(200);
		text.setStrokeWidth(20);
		text.setStyle(text.getStyle()
				+"-fx-fill: red;"
				+"-fx-font-size: 50;"
				+"-fx-font-weight: bold;"
				+"-fx-font-family: Garamond;");
		getChildren().add(text);
		
		//
		Light.Point lightSpace = new Light.Point(20, 20, 20, null);

		Lighting lighting = new Lighting();
		lighting.setLight(lightSpace);
		lighting.setSurfaceScale(0.0);

		setEffect(lighting);
		
		light = lightSpace;
	}
}
