package elements;

import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

public class Branch extends Line {
	
	public Branch() {
		initialized();
	}
	
	private void initialized() {
		setStrokeWidth(2);
		setStroke(Color.BROWN);
	}
	
	public void setLocation(Node node1, Node node2) {
		if ((node1 != null) && (node2 != null)) {
			setStartX(node1.getTranslateX());
			setStartY(node1.getTranslateY());
			setEndX(node2.getTranslateX());
			setEndY(node2.getTranslateY());
		}
	}
}
