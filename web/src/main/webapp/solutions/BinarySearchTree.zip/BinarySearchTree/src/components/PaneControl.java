package components;

import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;

public class PaneControl extends GridPane {
	
	public PaneControl() {
		initialized();
	}
	
	private void initialized() {
		setAlignment(Pos.CENTER);
		setStyle(getStyle()
				+"-fx-min-height: "+(1 * BSTButton.buttonHeight)+";"
				+"-fx-max-height: "+(1 * BSTButton.buttonHeight)+";"
				+"-fx-padding: -45 -45 -45 -25;"
				+"-fx-background-color: transparent;"
				+"-fx-border-color: black;"
				+"-fx-border-width: 50;"
				+"-fx-border-radius: 100 100 30 30;");
	}
}