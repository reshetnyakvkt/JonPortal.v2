package elements;

import application.BSTApplication;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;
import javafx.scene.text.Text;

public class Ball extends Sphere {
	private PhongMaterial material;
	
	EventHandler<MouseEvent> enteredBall;
	EventHandler<MouseEvent> exitedBall;
	
	public static double radius = 20;
	private double distance = radius * 3; // distance between leaves of tree
	private int number; // number on sphere
	public int level; // level in set
	public int position; // position of sphere relative to the parent (if 1 -> leftChild, if -1 -> rightChild)
	private double firstY = radius * 2;
	
	// children
	public Ball leftBall; // left child
	public Ball rightBall; // right child
	public Branch branch;
	public Text text;
	
	// constructor
	public Ball(int number) {
		material = new PhongMaterial();
		
		this.number = number;
		branch = new Branch();
		text = new Text(number+"");
		
		initialized();
	}
	
	private void initialized() {
		
		// EVENTS ON THE SPHERE
		
		enteredBall = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				changeBall1();
			}
		};
		
		exitedBall = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				changeBall2();
			}
		};
		
		// DESCRIPTION OF THE SPHERE
		
        text.setStyle(text.getStyle()
        			+"-fx-font-size: 18;"
        			+"-fx-font-weight: bold;"
        			+"-fx-fill: red;");
        text.setOnMouseEntered(enteredBall);
        text.setOnMouseExited(exitedBall);
        
		material.setDiffuseColor(Color.rgb(50,250,50));
        setMaterial(material);
        
		setRadius(radius);
		setFocusTraversable(false);
		setOnMouseEntered(enteredBall);
		setOnMouseExited(exitedBall);
	}
	
	private void changeBall1() {
		material.setDiffuseColor(Color.rgb(250,250,0));
	}
	
	private void changeBall2() {
		material.setDiffuseColor(Color.rgb(50,250,50));
	}
	
	public void setLocation(int level, int position, Ball parentBall) {
		if(parentBall == null) {
			this.level = level;
			this.position = position;
			setTranslateX(0);
			setTranslateY(firstY + level * distance);
			setTranslateZ(0);
			text.setTranslateX(getTranslateX() - radius/2);
			text.setTranslateY(getTranslateY() + radius/4);
			text.setTranslateZ(0);
			return;
		}
		this.level = level;
		this.position = position;
		setTranslateX(parentBall.getTranslateX() + 0.25 * position * distance * Math.exp((BSTApplication.treeHeight - level)*0.70));
		setTranslateY(firstY + level * distance);
		setTranslateZ(0);
		branch.setLocation(parentBall, this);
		text.setTranslateX(getTranslateX() - radius/2);
		text.setTranslateY(getTranslateY() + radius/4);
		text.setTranslateZ(0);
	}
	
	public void changeLocation(Ball parentBall) {
		setTranslateX(parentBall.getTranslateX() + 0.25 * position * distance * Math.exp((BSTApplication.treeHeight - level)*0.70));
		branch.setLocation(parentBall, this);
		text.setTranslateX(getTranslateX() - radius/2);
		text.setTranslateY(getTranslateY() + radius/4);
		text.setTranslateZ(0);
	}
	
	// getter
	
	public int getNumber() {
		return this.number;
	}
}
