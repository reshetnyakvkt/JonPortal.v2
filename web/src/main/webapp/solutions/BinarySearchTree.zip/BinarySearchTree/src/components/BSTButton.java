package components;

import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;

public class BSTButton extends Button {
	EventHandler<MouseEvent> enteredButton;
	EventHandler<MouseEvent> exitedButton;
	
	public static final double buttonWidth = 40;
	public static final double buttonHeight = 40;
	
	public BSTButton() {
		initialized();
	}
	
	private void initialized() {
		
		// EVENTS ON THE BUTTON
		
		enteredButton = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				enterButton();
			}
		};
		
		exitedButton = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				exitButton();
			}
		};
		
		setOnMouseEntered(enteredButton);
		setOnMouseExited(exitedButton);
	}
	
	// change the button style when the mouse cursor on it
	private void enterButton() {
		setStyle(getStyle()
				+"-fx-background-size: 100% 100%;");
	}
	
	// change the button style when the mouse cursor out it
	private void exitButton() {
		setStyle(getStyle()
				+"-fx-background-size: 80% 80%;");
	}
	
	// description of the button
	public void setProperties(String fileName, String tooltipText) {
		setStyle(getStyle()
				+"-fx-min-width: "+buttonWidth+";"
				+"-fx-min-height: "+buttonHeight+";"
				+"-fx-background-color: transparent;"
				+"-fx-background-size: 80% 80%;"
				+"-fx-background-image: url(\"file:images/"+fileName+"\");"
				+"-fx-background-position: center;"
				+ "-fx-background-repeat: no-repeat;");
		setTooltip(setTooltipStyle(tooltipText));
		setVisible(true);
		setFocusTraversable(false);
	}
	
	// create tooltip on the button
	private Tooltip setTooltipStyle(String text) {
		Tooltip tooltip = new Tooltip(text);
		tooltip.setStyle("-fx-font-weight: bold;"
						+"-fx-font-size: 12;"
						+"-fx-text-fill: darkgreen;"
						+"-fx-background-color: papayawhip;");
		return tooltip;
	}
}
