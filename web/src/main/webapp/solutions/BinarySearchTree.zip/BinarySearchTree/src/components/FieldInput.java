package components;

import javafx.scene.control.TextField;

public class FieldInput extends TextField {
	
	public FieldInput() {
		initialized();
	}
	
	private void initialized() {
		setStyle(getStyle()
				+"-fx-min-width: 50;"
				+"-fx-max-width: 50;"
				+"-fx-margin: 50;");
		setFocusTraversable(false);
	}
}
