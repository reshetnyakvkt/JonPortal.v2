package components;

import javafx.scene.layout.Pane;

public class PaneBalls extends Pane {
	
	public PaneBalls() {
		initialized();
	}
	
	private void initialized() {
		setTranslateX(0);
		setStyle(getStyle()
				+"-fx-background-size: 100% 100%;"
				+"-fx-background-position: center;"
				+"-fx-background-color: transparent;");
	}
}