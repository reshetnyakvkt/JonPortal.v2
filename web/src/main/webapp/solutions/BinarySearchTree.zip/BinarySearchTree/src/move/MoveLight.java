package move;

import components.PaneControl;
import components.PaneScreen;
import components.BSTPaneScroll;
import components.Space;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.effect.Light;

public class MoveLight extends Thread {
	private Light.Point light;
	private Scene scene;
	private Space space;
	private PaneControl paneControl;
	private BSTPaneScroll paneScroll;
	private PaneScreen paneScreen;
	
	public MoveLight(Light.Point light, Scene scene, Space space, PaneControl paneControl, BSTPaneScroll paneScroll, PaneScreen paneScreen) {
		this.light = light;
		this.scene = scene;
		this.space = space;
		this.paneControl = paneControl;
		this.paneScroll = paneScroll;
		this.paneScreen = paneScreen;
	}
	
	@Override
	public void run() {
		light.setX(0);
		light.setY(150);
		light.setZ(20);
		
		// ���������� ������������� ���������
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e2) {
			e2.printStackTrace();
		}
		for (int i = 0; i < 1200; i++) {
			Platform.runLater(() -> {
				light.setX(light.getX() + 0.7);
				light.setY((light.getY() + Math.pow(light.getX(), 1.1) / 8000));
				light.setZ(light.getZ() + 0.4);
			});

			try {
				Thread.sleep(4);
			} catch (InterruptedException e) {
			}
		}

		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
		}
		
		// ���������� ������������� ���������
		for (int i = 0; i < 2000; i++) {
			Platform.runLater(() -> {
				light.setX(light.getX() + 0.7);
				light.setY((light.getY() + Math.pow(light.getX() - 50, 1.1) / 8000));
				light.setZ(light.getZ() - 0.25);
			});

			try {
				Thread.sleep((long) (10 / Math.log(light.getX() * 10)));
			} catch (InterruptedException e) {
			}
		}
		
		Platform.runLater(() -> {
			paneScroll.setMinWidth(scene.getWidth());
			paneScroll.setMaxWidth(scene.getWidth());
			paneScroll.setMinHeight(scene.getHeight());
			paneScroll.setMaxHeight(scene.getHeight());
			
			paneScreen.setMinWidth(paneScroll.getMinWidth());
			paneScreen.setMaxWidth(paneScroll.getMaxWidth());
			paneScreen.setMinHeight(paneScroll.getMinHeight());
			paneScreen.setMaxHeight(paneScroll.getMaxHeight());
			
			space.setVisible(false);
			paneScroll.setVisible(true);
			paneControl.setVisible(true);
		});
	}
}
